# /pr-auto-merge - PR自動マージ
```bash
bash ~/miyabi-private/scripts/pr-auto-merge-bg.sh "$@"
```
