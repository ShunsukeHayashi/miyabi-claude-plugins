---
description: 毎日の開発進捗レポート自動生成 - note.com投稿用
---

# 毎日の開発進捗レポート自動生成

**かきこちゃん** & **えがくん** のコラボレーションで、今日の開発進捗をnote.com記事として自動生成します。

## 🚀 実行フロー

```
/daily-update
    ↓
1️⃣ Git情報自動収集
   - 今日のコミット履歴
   - 変更ファイル統計
   - Issue/PR進捗
   - 追加/削除行数
    ↓
2️⃣ かきこちゃん（NoteAgent）実行
   - 6,000文字の日次レポート生成
   - [--IMAGE--] プレースホルダー配置
   - Amazon アソシエイトリンク挿入（tag=shuhayas-22）
   - C1-C6 ワークフロー実行
    ↓
3️⃣ えがくん（ImageGenAgent）実行
   - PlantUML図生成（進捗グラフ、統計等）
   - DALL-E 3プロンプト生成
   - プレースホルダー置換
    ↓
4️⃣ ファイル保存
   - docs/daily-updates/YYYY-MM-DD.md
   - docs/daily-updates/images/YYYY-MM-DD/
    ↓
5️⃣ Git commit
   - 自動コミット & プッシュ（オプション）
```

## 📝 実行コマンド

### 基本実行（今日の進捗）

```bash
/daily-update
```

### 特定日の進捗レポート生成

```bash
/daily-update --date 2025-10-21
```

### Dry run（生成のみ、保存しない）

```bash
/daily-update --dry-run
```

### カスタムトピック追加

```bash
/daily-update --topic "Rust移行完了記念"
```

## 🎯 実行手順（Claude Code向け）

このコマンドが実行されたら、以下の手順を厳密に従ってください：

### Step 1: Git情報収集

```bash
# 今日の日付を取得
TODAY=$(date +%Y-%m-%d)

# 今日のコミット一覧
git log --since="$TODAY 00:00:00" --until="$TODAY 23:59:59" --pretty=format:"%h - %s" --no-merges

# 今日の変更統計
git diff --shortstat $(git log --since="$TODAY 00:00:00" --format="%H" | tail -1)^ HEAD

# 今日処理されたIssue（コミットメッセージから抽出）
git log --since="$TODAY 00:00:00" --grep="Issue #" --pretty=format:"%s"

# 今日のPR
gh pr list --search "created:$TODAY" --json number,title,url
```

**収集する情報**:
- ✅ コミット数
- ✅ 追加行数 / 削除行数
- ✅ 変更ファイル数
- ✅ 処理されたIssue番号とタイトル
- ✅ 作成されたPR番号とタイトル
- ✅ 主要な変更内容（コミットメッセージから）

### Step 2: コンテキスト構造化

収集した情報を以下の形式でJSON化：

```json
{
  "date": "2025-10-22",
  "summary": {
    "commits": 5,
    "filesChanged": 12,
    "additions": 342,
    "deletions": 89,
    "issues": [
      {"number": 270, "title": "Add user authentication"},
      {"number": 271, "title": "Fix memory leak"}
    ],
    "prs": [
      {"number": 280, "title": "feat: add Rust migration", "url": "..."}
    ]
  },
  "highlights": [
    "Rust移行完了 - 50%高速化達成",
    "かきこちゃん & えがくん追加",
    "23 Agents完成"
  ],
  "nextSteps": [
    "Windows完全サポート",
    "SWE-bench Pro統合"
  ]
}
```

### Step 3: かきこちゃん（NoteAgent）実行

**プロンプトファイル**: `/Users/a003/dev/miyabi-private/.claude/agents/prompts/business/note-agent-prompt.md`

**実行指示**:
```markdown
以下のGit情報を基に、今日の開発進捗レポート記事を執筆してください。

## コンテキスト（Git情報）
{上記で収集したJSON}

## 記事要件
- タイトル: 「【開発日誌 YYYY-MM-DD】Miyabi開発進捗 - [主要トピック]」
- 文字数: 3,000〜4,000文字（日次レポートなので通常より短め）
- 構成:
  1. 今日のハイライト（3〜5箇所）
  2. 詳細な変更内容（コミット別）
  3. Issue/PR進捗
  4. 次のステップ
  5. 技術的学び（あれば）
- [--IMAGE--]: 2〜3箇所配置
- Amazon アソシエイト: 1〜2箇所（関連書籍）
- トーン: フレンドリー、技術的かつわかりやすく

## アカウント情報
- Twitter: @The_AGI_WAY
- note: note.ambitiousai.co.jp
- Amazonタグ: tag=shuhayas-22
```

**期待される出力**: `docs/daily-updates/YYYY-MM-DD-draft.md`

### Step 4: えがくん（ImageGenAgent）実行

**プロンプトファイル**: `/Users/a003/dev/miyabi-private/.claude/agents/prompts/business/imagegen-agent-prompt.md`

**実行指示**:
```markdown
かきこちゃんが生成した記事（docs/daily-updates/YYYY-MM-DD-draft.md）の
[--IMAGE--] プレースホルダーを検出し、適切な画像を生成してください。

## 日次レポート用画像種別

### 1. 進捗グラフ（PlantUML）
- コミット数推移
- Issue処理数
- ファイル変更統計

### 2. 技術スタック図（PlantUML）
- 今日追加されたコンポーネント
- アーキテクチャ変更

### 3. アイキャッチ（DALL-E 3プロンプトのみ）
- 今日のハイライトをビジュアル化
- Miyabi aesthetic: minimalist, Japanese, tech-forward

## 保存先
- PlantUML: docs/daily-updates/images/YYYY-MM-DD/
- 最終記事: docs/daily-updates/YYYY-MM-DD.md（draftから移動）
```

**期待される出力**:
- `docs/daily-updates/images/YYYY-MM-DD/*.png` (PlantUML図)
- `docs/daily-updates/YYYY-MM-DD.md`（完成記事）

### Step 5: 品質チェック

自動チェックリスト：

- [ ] 記事文字数: 3,000〜4,000文字 ✅
- [ ] 画像配置: 2〜3箇所 ✅
- [ ] Amazonリンク: すべて `tag=shuhayas-22` 付き ✅
- [ ] Markdown構文: エラーなし ✅
- [ ] Git情報: 正確に反映されている ✅
- [ ] PlantUML図: PNG生成成功 ✅

### Step 6: Git commit

```bash
git add docs/daily-updates/
git commit -m "$(cat <<'EOF'
docs(daily): add development progress report for $(date +%Y-%m-%d)

Today's highlights:
- X commits, Y files changed (+A, -B lines)
- Issue #N1, #N2 processed
- PR #M1 created

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: かきこちゃん (NoteAgent) <noreply@anthropic.com>
Co-Authored-By: えがくん (ImageGenAgent) <noreply@anthropic.com>
EOF
)"
```

### Step 7: 完了報告

```markdown
## ✅ 日次進捗レポート生成完了！

**生成日**: YYYY-MM-DD
**記事**: docs/daily-updates/YYYY-MM-DD.md
**画像**: docs/daily-updates/images/YYYY-MM-DD/

### 📊 統計情報
- 文字数: 3,456文字
- 画像: 3枚（PlantUML 2枚 + アイキャッチ提案 1件）
- Amazonリンク: 2箇所

### 📝 次のアクション
1. 外部でDALL-E 3アイキャッチ画像を生成
2. note.comに投稿（手動 or 自動）
3. TwitterでシェアURL投稿

### 🔗 記事プレビュー
[記事の最初の100文字...]
```

## 🎨 日次レポート記事テンプレート

かきこちゃんは以下のテンプレートを基に記事を生成します：

```markdown
# 【開発日誌 YYYY-MM-DD】Miyabi開発進捗 - [ハイライト]

[--IMAGE--]

今日も一日、Miyabi開発を進めました！🚀

## 📊 今日の統計

| 項目 | 数値 |
|------|------|
| コミット数 | X件 |
| ファイル変更 | Y件 |
| 追加行数 | +A行 |
| 削除行数 | -B行 |
| Issue処理 | N件 |
| PR作成 | M件 |

## 🎯 今日のハイライト

1. **[ハイライト1]**
   - 詳細説明...

2. **[ハイライト2]**
   - 詳細説明...

[--IMAGE--]

## 🔨 主な変更内容

### コミット: [hash] - [message]
- 変更ファイル: ...
- 影響範囲: ...
- 技術的詳細: ...

## 📋 Issue/PR進捗

### Issue #270: [タイトル]
- ステータス: 完了 ✅
- 担当Agent: つくるん, めだまん
- 所要時間: 10分

## 💡 技術的学び

今日得た知見やハマったポイント...

## 🚀 次のステップ

明日以降の予定:
- [ ] タスク1
- [ ] タスク2

[--IMAGE--]

---

## 📚 関連リンク

おすすめ書籍:
- [書籍名](Amazon URL with tag=shuhayas-22)

---

**この記事は、かきこちゃん & えがくん により自動生成されました。**
```

## 📁 ディレクトリ構造

```
docs/
└── daily-updates/
    ├── 2025-10-22.md          # 今日の記事
    ├── 2025-10-21.md          # 昨日の記事
    ├── images/
    │   ├── 2025-10-22/
    │   │   ├── progress-chart.png
    │   │   ├── commit-stats.png
    │   │   └── architecture.png
    │   └── 2025-10-21/
    │       └── ...
    └── README.md              # 日次レポート一覧
```

## ⚙️ オプション詳細

| オプション | 説明 | デフォルト |
|-----------|------|-----------|
| `--date <YYYY-MM-DD>` | 特定日のレポート生成 | 今日 |
| `--dry-run` | 生成のみ（保存しない） | false |
| `--topic <text>` | カスタムトピック追加 | - |
| `--skip-images` | 画像生成をスキップ | false |
| `--skip-commit` | Git commitをスキップ | false |
| `--output <path>` | 保存先カスタマイズ | docs/daily-updates/ |

## 📌 使用例

### 例1: 基本実行

```bash
$ /daily-update

🤖 Daily Progress Report Generator

✅ Git information collected
   - 5 commits today
   - 12 files changed (+342, -89)
   - Issues: #270, #271
   - PRs: #280

✅ かきこちゃん: Article generated (3,456 chars)
✅ えがくん: 3 images generated
✅ Saved to: docs/daily-updates/2025-10-22.md
✅ Committed to Git

📝 Next steps:
1. Generate DALL-E 3 eyecatch image
2. Post to note.com
3. Share on Twitter
```

### 例2: カスタムトピック追加

```bash
$ /daily-update --topic "Rust移行完了記念🎉"

# タイトル: 【開発日誌 2025-10-22】Miyabi開発進捗 - Rust移行完了記念🎉
```

### 例3: Dry run（確認のみ）

```bash
$ /daily-update --dry-run

# 記事生成のみ、ファイル保存・コミットはしない
# プレビュー確認用
```

## 🔧 トラブルシューティング

### Git情報が取得できない

```bash
❌ Error: No commits found for today

解決策:
- 日付指定を確認: --date 2025-10-21
- Gitログを手動確認: git log --oneline --since="today"
```

### かきこちゃん実行エラー

```bash
❌ Error: NoteAgent prompt file not found

解決策:
- プロンプトファイルを確認: .claude/agents/prompts/business/note-agent-prompt.md
- ファイルが存在するか確認
```

### PlantUML生成エラー

```bash
❌ Error: plantuml command not found

解決策:
brew install plantuml
```

## 🎯 成功条件

✅ **必須**:
- Git情報収集成功
- 記事文字数 3,000〜4,000文字
- 画像 2〜3枚生成
- Markdown構文エラーなし
- ファイル保存成功

✅ **品質**:
- Amazonリンク全て `tag=shuhayas-22` 付き
- PlantUML図が正しく生成されている
- 記事の論理構成が明確
- 技術的正確性

## 📖 関連コマンド

- `/review` - 生成された記事のレビュー
- `/test` - Markdown構文チェック
- `/generate-docs` - ドキュメント再生成

## 🔗 関連ドキュメント

- [NoteAgent仕様](.claude/agents/specs/business/note-agent.md)
- [ImageGenAgent仕様](.claude/agents/specs/business/imagegen-agent.md)
- [かきこちゃんプロンプト](.claude/agents/prompts/business/note-agent-prompt.md)
- [えがくんプロンプト](.claude/agents/prompts/business/imagegen-agent-prompt.md)

---

**毎日の開発を記録し、振り返りと共有を習慣化しましょう！** 📝✨
