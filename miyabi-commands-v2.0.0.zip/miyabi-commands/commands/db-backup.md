# /db-backup - データベースバックアップ
```bash
bash ~/miyabi-private/scripts/db-backup-bg.sh
```
