# /test-escalation - エスカレーション通知テスト

## 使い方
```bash
/test-escalation P0 "Critical error detected"
/test-escalation P1 "High priority alert"
```

## 実装
```bash
bash ~/.claude/scripts/test-escalation.sh "$@"
```
