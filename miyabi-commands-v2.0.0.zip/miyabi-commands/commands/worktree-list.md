# /worktree-list - Worktree一覧
```bash
bash ~/miyabi-private/scripts/worktree-list-bg.sh
```
