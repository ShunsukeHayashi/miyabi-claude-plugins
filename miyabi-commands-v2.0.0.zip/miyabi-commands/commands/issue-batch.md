# /issue-batch - Issue一括作成
```bash
bash ~/miyabi-private/scripts/issue-batch-bg.sh "$@"
```
