# /worktree-cleanup - Worktree削除
```bash
bash ~/miyabi-private/scripts/worktree-cleanup-bg.sh "$@"
```
