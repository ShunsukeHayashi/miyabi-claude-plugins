# /dashboard - ダッシュボード表示

## 使い方
```bash
/dashboard
/dashboard --full
```

## 実装
```bash
bash ~/miyabi-private/scripts/dashboard-bg.sh "$@"
```
