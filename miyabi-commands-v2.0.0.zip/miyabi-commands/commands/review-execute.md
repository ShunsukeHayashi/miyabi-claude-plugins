# /review-execute - 品質チェック

## 使い方
```bash
/review-execute 888
```

## 実装
```bash
bash ~/miyabi-private/scripts/review-execute-bg.sh "$@"
```
