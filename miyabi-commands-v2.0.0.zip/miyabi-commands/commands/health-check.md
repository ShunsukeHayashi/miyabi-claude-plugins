# /health-check - ヘルスチェック
```bash
bash ~/miyabi-private/scripts/health-check-bg.sh
```
