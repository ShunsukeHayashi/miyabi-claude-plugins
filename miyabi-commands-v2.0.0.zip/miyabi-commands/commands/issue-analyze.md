# /issue-analyze - Issue分析
```bash
bash ~/miyabi-private/scripts/issue-analyze-bg.sh "$@"
```
