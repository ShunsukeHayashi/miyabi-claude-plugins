# /parallel-execute - 並列実行
```bash
bash ~/miyabi-private/scripts/parallel-execute-bg.sh "$@"
```
