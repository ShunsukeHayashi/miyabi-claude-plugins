---
name: Business Strategy and Planning
description: Comprehensive business planning including self-analysis, product concept, persona development, and 8-phase business plan creation. Use when creating business plans or product strategies.
allowed-tools: Read, Write, WebFetch, Bash
---

# 💼 Business Strategy and Planning

**Version**: 2.0.0
**Last Updated**: 2025-11-22
**Priority**: ⭐⭐⭐ (P2 Level - Business)
**Purpose**: 事業戦略立案、プロダクト設計、ペルソナ開発

---

## 📋 概要

自己分析から8フェーズ事業計画まで、包括的なビジネスプランニングを提供。
Business Agents（じぶんるん、つくるそん、ぺるそん、あきんどさん）との連携。

---

## 🎯 P0: 呼び出しトリガー

| トリガー | 例 |
|---------|-----|
| 事業計画 | "create a business plan" |
| 製品戦略 | "define our product strategy" |
| 顧客特定 | "identify target customers" |
| 新規事業 | "starting new business/product" |

---

## 🔧 P1: 戦略フレームワーク

### 8フェーズ事業計画

| Phase | 内容 | Agent | 成果物 |
|-------|------|-------|--------|
| 1 | 自己分析 | じぶんるん | 強み/弱み分析 |
| 2 | 製品コンセプト | つくるそん | USP、BMC |
| 3 | ペルソナ設計 | ぺるそん | 3-5ペルソナ |
| 4 | 市場分析 | しらべるん | TAM/SAM/SOM |
| 5 | 収益モデル | あきんどさん | 価格戦略 |
| 6 | GTM戦略 | ひろめるん | チャネル計画 |
| 7 | 財務計画 | すうじるん | 3年予測 |
| 8 | 実行計画 | あきんどさん | ロードマップ |

---

## 🚀 P2: 分析テンプレート

### Pattern 1: BMC（Business Model Canvas）

```
┌─────────────┬─────────────┬─────────────┐
│ Key Partners│ Key Activities│ Value Prop │
├─────────────┼─────────────┼─────────────┤
│ Key Resources│ Channels   │ Customer   │
│             │             │ Segments   │
├─────────────┴─────────────┼─────────────┤
│ Cost Structure            │ Revenue    │
│                           │ Streams    │
└───────────────────────────┴─────────────┘
```

### Pattern 2: TAM/SAM/SOM

| 市場 | 定義 | 算出方法 |
|------|------|---------|
| **TAM** | 全体市場規模 | 業界レポート |
| **SAM** | 獲得可能市場 | TAM × 地域/セグメント |
| **SOM** | 実現可能市場 | SAM × シェア予測 |

### Pattern 3: ペルソナテンプレート

```yaml
Persona:
  name: "田中太郎"
  age: 35
  role: "IT企業マネージャー"
  pain_points:
    - "チーム生産性向上"
    - "ツール管理の煩雑さ"
  goals:
    - "効率化で残業削減"
    - "チームモチベーション向上"
  buying_criteria:
    - "ROI明確"
    - "導入容易性"
```

---

## ⚡ P3: 収益モデル

### 価格戦略オプション

| モデル | 特徴 | 適合 |
|--------|------|------|
| Freemium | 無料→有料転換 | SaaS, B2C |
| Subscription | 月額/年額 | SaaS, B2B |
| Usage-based | 従量課金 | API, Infrastructure |
| Tiered | 段階価格 | 多様な顧客層 |

### LTV計算

```
LTV = ARPU × Gross Margin × (1 / Churn Rate)
例: ¥10,000 × 70% × (1/5%) = ¥140,000
```

---

## ✅ 成功基準

| 成果物 | 基準 |
|--------|------|
| BMC | 9要素完成 |
| ペルソナ | 3-5人定義 |
| TAM/SAM/SOM | 数値根拠あり |
| 財務計画 | 3年予測 |

---

## 🔗 関連Skills

- **Market Research**: 市場データ
- **Growth Analytics**: KPI設計
- **Sales CRM**: 営業戦略
