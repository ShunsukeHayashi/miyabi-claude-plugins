---
name: Growth Analytics and Dashboard Management
description: KPI framework setup, dashboard design, cohort analysis, and data-driven decision making. Use when analyzing growth metrics, building KPI dashboards, or implementing analytics systems.
allowed-tools: Read, Write, WebFetch, Bash
---

# 📊 Growth Analytics and Dashboard Management

**Version**: 2.0.0
**Last Updated**: 2025-11-22
**Priority**: ⭐⭐⭐⭐ (P1 Level - Business)
**Purpose**: KPIフレームワーク、ダッシュボード設計、データドリブン意思決定

---

## 📋 概要

20以上のメトリクスによるKPIフレームワーク、ダッシュボード設計、
コホート分析、予測分析を通じたグロース支援を提供します。

---

## 🎯 P0: 呼び出しトリガー

| トリガー | 例 |
|---------|-----|
| メトリクス分析 | "analyze our growth metrics" |
| CAC/LTV | "what's our CAC/LTV?" |
| ダッシュボード | "build a KPI dashboard" |
| データ分析 | "data-driven decisions" |
| コホート | "cohort analysis" |

---

## 🔧 P1: KPIカテゴリ一覧

### 5カテゴリ・20+メトリクス

| カテゴリ | メトリクス | 優先度 | 測定頻度 |
|---------|----------|--------|---------|
| **Acquisition** | CAC, Traffic, Conversion | 高 | 週次 |
| **Activation** | Time-to-Value, Onboarding Rate | 高 | 週次 |
| **Revenue** | MRR, ARPU, LTV | 高 | 月次 |
| **Retention** | Churn, NRR, DAU/MAU | 高 | 月次 |
| **Referral** | NPS, Viral Coefficient | 中 | 四半期 |

---

## 🚀 P2: ダッシュボード設計

### Dashboard Types

| Type | 対象 | 更新頻度 | メトリクス数 |
|------|------|---------|------------|
| **Executive** | 経営層 | 週次 | 5-7 |
| **Product** | PM/開発 | 日次 | 10-15 |
| **Marketing** | マーケ | 日次 | 8-12 |
| **Sales** | 営業 | リアルタイム | 6-10 |

### Pattern 1: Executive Dashboard

```
┌─────────────────────────────────────────────┐
│              Executive Dashboard             │
├─────────────┬─────────────┬─────────────────┤
│    MRR      │   Churn     │     NPS         │
│   ¥XXX万    │    2.1%     │      42         │
│   ↑12% MoM  │   ↓0.3%     │    ↑5 pts       │
├─────────────┼─────────────┼─────────────────┤
│    CAC      │    LTV      │   LTV/CAC       │
│   ¥8,500    │   ¥85,000   │     10.0x       │
│   ↓5%       │   ↑8%       │    ↑1.2x        │
└─────────────┴─────────────┴─────────────────┘
```

### Pattern 2: Product Dashboard

```yaml
Metrics:
  - DAU/MAU (Stickiness)
  - Feature Adoption Rate
  - Time-in-App
  - Error Rate
  - Page Load Time
  - User Journey Completion
```

---

## ⚡ P3: 分析手法

### Cohort Analysis

| 月 | Week 1 | Week 2 | Week 3 | Week 4 |
|----|--------|--------|--------|--------|
| Jan | 100% | 65% | 52% | 48% |
| Feb | 100% | 68% | 55% | 51% |
| Mar | 100% | 72% | 58% | 54% |

**解釈**: リテンション改善トレンド（+6% W4）

### Funnel Analysis

```
Awareness  : 10,000 (100%)
    ↓
Interest   :  3,000 (30%)   ← Drop: 70%
    ↓
Evaluation :  1,200 (12%)   ← Drop: 60%
    ↓
Trial      :    600 (6%)    ← Drop: 50%
    ↓
Purchase   :    300 (3%)    ← Drop: 50%
```

**改善ポイント**: Interest→Evaluation (60% drop)

### A/B Testing Framework

| 要素 | 内容 |
|------|------|
| 仮説 | 「CTA色変更で+10% CVR」 |
| サンプルサイズ | 1,000 per variant |
| 期間 | 2週間 |
| 成功基準 | p < 0.05, +5% CVR |

---

## 📊 PDCA サイクル

### 4週間スプリント

| 週 | フェーズ | アクション |
|----|---------|-----------|
| Week 1 | Plan | KPI設定、仮説立案 |
| Week 2 | Do | 施策実行、データ収集 |
| Week 3 | Check | 分析、結果評価 |
| Week 4 | Act | 改善、次サイクル準備 |

---

## 🛡️ 予測分析

### Churn Prediction

```
リスクスコア = 
  ログイン頻度低下 × 0.3 +
  機能利用減少 × 0.25 +
  サポート問い合わせ × 0.2 +
  契約更新近接 × 0.15 +
  決済失敗履歴 × 0.1
```

| スコア | リスク | アクション |
|--------|--------|-----------|
| 0-30 | 低 | 通常対応 |
| 31-60 | 中 | プロアクティブ連絡 |
| 61-100 | 高 | 緊急介入 |

### Revenue Forecasting

```
予測MRR = 
  現在MRR × (1 - Churn%) +
  New MRR (リード × CVR × ARPU) +
  Expansion MRR (アップセル対象 × Rate)
```

---

## ✅ 成功基準

| メトリクス | 目標 | 測定 |
|-----------|------|------|
| LTV/CAC | >3.0x | 月次 |
| Churn | <5% | 月次 |
| NPS | >40 | 四半期 |
| DAU/MAU | >30% | 週次 |

---

## 🔗 関連Skills

- **Market Research**: 市場データ収集
- **Sales CRM**: 営業メトリクス
- **Content Marketing**: マーケティングKPI
- **Business Strategy**: 戦略立案との連携
