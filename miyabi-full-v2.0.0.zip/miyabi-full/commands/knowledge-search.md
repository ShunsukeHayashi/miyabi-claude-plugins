# /knowledge-search - ナレッジ検索
```bash
bash ~/miyabi-private/scripts/knowledge-search-bg.sh "$@"
```
