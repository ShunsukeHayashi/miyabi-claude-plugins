# /worktree-dashboard - Worktree管理ダッシュボード
```bash
bash ~/miyabi-private/scripts/worktree-dashboard.sh
```
