# /pr-list - PR一覧
```bash
bash ~/miyabi-private/scripts/pr-list-bg.sh
```
