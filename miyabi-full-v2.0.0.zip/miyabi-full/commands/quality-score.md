# /quality-score - 品質スコア
```bash
bash ~/miyabi-private/scripts/quality-score-bg.sh
```
