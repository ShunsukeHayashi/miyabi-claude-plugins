# /codegen-execute - コード生成実行

## 使い方
```bash
/codegen-execute 887
```

## 機能
1. CodeGenAgent実行
2. コード自動生成
3. テスト実行

## 実装
```bash
bash ~/miyabi-private/scripts/codegen-execute-bg.sh "$@"
```
