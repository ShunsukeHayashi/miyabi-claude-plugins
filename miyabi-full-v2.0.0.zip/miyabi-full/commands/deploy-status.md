# /deploy-status - デプロイ状況
```bash
bash ~/miyabi-private/scripts/deploy-status-bg.sh
```
