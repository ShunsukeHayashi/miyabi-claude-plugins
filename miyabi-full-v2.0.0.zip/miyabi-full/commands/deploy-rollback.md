# /deploy-rollback - ロールバック
```bash
bash ~/miyabi-private/scripts/deploy-rollback-bg.sh "$@"
```
