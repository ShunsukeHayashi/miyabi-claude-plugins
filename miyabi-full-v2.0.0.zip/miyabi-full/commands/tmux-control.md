---
description: TmuxControlAgentでtmuxセッションを管制する
---

# tmux 制御コマンド `/tmux-control`

TmuxControlAgent（つむっくん）が tmux セッションを監視・指示するためのスラッシュコマンド。  
`/docs/TMUX_AI_AGENT_CONTROL_GUIDE.md` の実行手順をスクリプト化し、セッション整備・指示送信・ログ収集を自動化します。

## 📦 主要機能

- セッション存在確認（`ensureSession`）と自動再生成  
- Pane への安全な `send-keys` 注入（100ms スリープ + Enter）  
- `capture-pane` でのログ取得と成功/失敗判定  
- `/clear`・`kill-pane` など復旧手順の自動化  
- 制御モード（`tmux -CC`）を利用したイベント購読（オプション）

## 🔧 パラメータ

| 引数 | 必須 | 説明 | 例 |
|------|------|------|----|
| `session` | 任意 | 対象セッション名（未指定は `miyabi-auto-dev`） | `session=Miyabi` |
| `pane` | 任意 | 対象 pane ID（未指定は `tmux_agents_control.md` で定義されたデフォルト） | `pane=%4` |
| `command` | 任意 | 実行させたい指示本文 | `command=cd ... && npm run tauri dev` |
| `mode` | 任意 | `send`（default） / `capture` / `recover` / `status` | `mode=capture` |

## 🚀 使用例

```
/tmux-control session=miyabi-auto-dev pane=%4 command="cd '/Users/.../miyabi-desktop' && npm run tauri dev"
/tmux-control session=Miyabi mode=status
/tmux-control pane=%2 mode=recover
```

## 🧭 実行フロー

```
セッション確認 → Pane マッピング → 指示送信（send-keys） → 100ms 待機 → Enter
    ↓
capture-pane でログ取得 → 成功/失敗マッチャーで判定
    ↓
異常時は /clear → 再指示 → (必要に応じ kill-pane / kill-session)
    ↓
結果を CoordinatorAgent へ通知
```

## 📚 参照ドキュメント

- `/docs/TMUX_AI_AGENT_CONTROL_GUIDE.md` – フルガイド  
- `.claude/guides/TMUX_AI_AGENT_CONTROL.md` – 運用プレイブック  
- `.claude/agents/specs/coding/tmux-control-agent.md` – Agent 仕様書

## ✅ ベストプラクティス

- 指示は 1 コマンドずつ送信し、行末に `&& sleep 0.1 && tmux send-keys ... Enter` を追加。  
- 新タスク開始前には `/clear` を送ってログを区切る。  
- `mode=status` や `mode=capture` を活用し、ログ解析前に必要なコンテキストを取得。  
- 復旧不能 (`mode=recover` で 3 回失敗) の場合は CoordinatorAgent に `status:critical` を返し、人間オペレーターに連絡。

## 🛡️ セーフティ

- `command` 引数はホワイトリストチェック後に送信。危険コマンド (rm, shutdown など) は拒否。  
- `kill-session` を伴う操作は二重確認プロンプトあり。  
- `tmux -vv` ログを必要に応じて自動採取し、`logs/` ディレクトリへ保存。

---

つむっくん（TmuxControlAgent）が tmux の交通整理を担当することで、AI 主導の CLI 操作が安定します。複雑なセッション構成でも `/tmux-control` で一貫した制御が可能です。
