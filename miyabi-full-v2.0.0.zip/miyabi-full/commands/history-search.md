# /history-search - 履歴検索
```bash
bash ~/miyabi-private/scripts/history-search-bg.sh "$@"
```
