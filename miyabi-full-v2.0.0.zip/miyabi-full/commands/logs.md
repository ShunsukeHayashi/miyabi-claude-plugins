# /logs - ログ表示
```bash
bash ~/miyabi-private/scripts/logs-bg.sh
```
