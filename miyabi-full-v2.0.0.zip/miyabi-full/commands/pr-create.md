# /pr-create - PR作成

## 使い方
```bash
/pr-create 889 --title="Fix bug"
```

## 実装
```bash
bash ~/miyabi-private/scripts/pr-create-bg.sh "$@"
```
