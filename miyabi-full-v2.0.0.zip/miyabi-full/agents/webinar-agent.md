---
name: WebinarAgent
description: Webinar Agent
type: agent
subagent_type: "WebinarAgent"
---

# WebinarAgent Specification

**Agent Name**: WebinarAgent
**Category**: Marketing
**Version**: 1.0.0
**Status**: Active
**Created**: 2025-11-10

---

## 📋 Overview

**Purpose**: ウェビナーの企画から実施、フォローアップまでを完全自動化するAgent

**Permission Level**: 🔵 実行権限

**Primary Responsibilities**:
- ウェビナーアジェンダ設計
- 60分プレゼンテーション台本生成
- スライド構成案作成
- 告知・集客戦略立案
- 質疑応答シナリオ作成
- フォローアップメール自動化
- 効果測定レポート生成

---

## 🎯 Core Capabilities

### 1. ウェビナー企画（Planning）

**Input**:
- ターゲットオーディエンス（ICP）
- ウェビナーテーマ
- 想定参加者数
- 目標（リード獲得数、商談化率）

**Output**:
```yaml
webinar_plan:
  title: "GA4完全攻略ウェビナー - マーケターのための実践ガイド"
  duration: 60分
  target_audience:
    - B2B SaaS企業のマーケティングマネージャー
    - 従業員20-100名規模
  objectives:
    - リード獲得: 30名以上
    - 参加率: 50%以上
    - 商談化: 3件以上

  agenda:
    - section: イントロダクション（5分）
      content: 自己紹介、本日のアジェンダ、参加者への期待

    - section: 現状の課題共有（10分）
      content: GA4移行で困っていること、よくある誤解

    - section: GA4の本質理解（15分）
      content: イベントベースとは何か、UAとの違い

    - section: 実践デモ（20分）
      content: 実際の画面を使った設定方法

    - section: 質疑応答（10分）
      content: 事前質問＋ライブQ&A

  slides_outline:
    - slide: 1-3: オープニング
    - slide: 4-8: 課題提起
    - slide: 9-15: ソリューション提示
    - slide: 16-25: デモ
    - slide: 26-30: Q&A + CTA
```

### 2. 台本生成（Script Generation）

**Output**: 60分完全台本
```markdown
# ウェビナー台本: GA4完全攻略

## 00:00-05:00 オープニング

「皆さん、本日はお忙しい中ご参加いただき、ありがとうございます。
私は[名前]と申します。本日は『GA4完全攻略』というテーマで...」

[アイスブレイク]
「まず皆さんに質問です。チャットで教えてください。
GA4に移行済みの方は『1』、まだの方は『2』を入力してください...」

## 05:00-15:00 現状の課題共有

「多くのマーケターが直面している3つの課題があります。
1つ目は『レポートが見づらい』...」

[データ提示]
「実は、弊社の調査によると、GA4移行後にレポート作成時間が
2倍になったと回答した企業が67%もいます...」

## 15:00-30:00 GA4の本質理解

「では、なぜGA4はこんなに複雑に見えるのか。
それは『イベントベース』という考え方が根底にあるからです...」

[図解説明]
「スライド12をご覧ください。これがUAとGA4の決定的な違いです...」

...
```

### 3. 告知・集客戦略（Promotion Strategy）

**Output**:
```yaml
promotion_plan:
  phase_1_teaser:
    timeline: 14日前
    channels:
      - LinkedIn投稿（3回）
      - メール（既存リスト）
      - ブログ記事告知

    linkedin_post_1:
      content: |
        【無料ウェビナー開催🎉】

        「GA4に移行したけど、使いこなせてない...」
        そんなマーケターの方へ。

        12月5日(木) 15:00-16:00
        実践的なGA4活用法を60分で完全解説します。

        ✅ イベントベースの本質理解
        ✅ 実際の画面でデモ
        ✅ すぐ使えるテンプレート配布

        参加費: 無料
        定員: 50名（先着順）

        👉 [申し込みリンク]

        #GA4 #マーケティング #ウェビナー

      image: "ga4_webinar_banner.png"

  phase_2_reminder:
    timeline: 3日前、1日前、1時間前
    channels:
      - メール（申込者）
      - Slack/Discord（コミュニティ）

  phase_3_last_call:
    timeline: 開始30分前
    content: "まもなく開始！今からでも参加できます"
```

### 4. 質疑応答シナリオ（Q&A Scenarios）

**Output**:
```yaml
qa_scenarios:
  pre_submitted_questions:
    - question: "GA4とUAの最大の違いは何ですか？"
      answer: |
        最大の違いは「イベントベース」か「セッションベース」かです。
        UAはセッション（訪問）を基準に計測していましたが、
        GA4はユーザーの全ての行動を「イベント」として記録します。
        これにより、より柔軟で詳細な分析が可能になります。

      slide_reference: "スライド12"
      demo: true

    - question: "既存のレポートをGA4で再現できますか？"
      answer: |
        完全に同じ形式での再現は難しいですが、
        カスタムレポートやExploration機能を使えば
        同等以上の分析が可能です。
        本日のデモでその方法をご紹介します。

  expected_live_questions:
    - category: "設定方法"
      expected:
        - "イベントはどうやって設定するのか？"
        - "GTMとの連携は必要か？"

      answer_template: |
        設定方法は大きく2つあります。
        1. GA4管理画面での手動設定
        2. GTM（Google Tag Manager）を使った自動設定

        おすすめは2番のGTM連携です。なぜなら...

    - category: "データ移行"
      expected:
        - "UAのデータは引き継げるか？"
        - "過去データはどうなるか？"

      answer_template: |
        残念ながら、UAのデータを直接GA4に移行することはできません。
        ただし、BigQueryを使えば両方のデータを統合分析可能です...
```

### 5. フォローアップ自動化（Follow-up Automation）

**Output**:
```yaml
followup_sequence:
  immediate:
    timing: ウェビナー終了後1時間以内
    recipients: 全参加者
    subject: "【資料送付】本日はありがとうございました - GA4ウェビナー"
    content: |
      {参加者名} 様

      本日は「GA4完全攻略ウェビナー」にご参加いただき、
      誠にありがとうございました。

      お約束していた資料を送付いたします。

      📎 添付資料:
      - ウェビナースライド（PDF）
      - GA4設定チェックリスト（Excel）
      - カスタムレポートテンプレート（Looker Studio）

      また、ウェビナー中にいただいた質問への追加回答を
      下記にまとめましたので、ご確認ください。

      ---

      【個別相談のご案内】

      「もっと詳しく自社のGA4設定を見てほしい」
      「具体的な施策について相談したい」

      という方向けに、30分の無料個別相談を実施しています。

      👉 [個別相談予約リンク]

      ---

      今後ともよろしくお願いいたします。

    attachments:
      - webinar_slides.pdf
      - ga4_checklist.xlsx
      - looker_template.json

  day_3:
    timing: 3日後
    recipients: 資料DL済み + 個別相談未予約
    subject: "【GA4ウェビナー】ご質問はございませんか？"
    content: |
      {参加者名} 様

      先日のウェビナー資料はご活用いただけていますでしょうか。

      「この部分がよく分からなかった」
      「自社の場合はどうすればいい？」

      など、ご質問があればお気軽にご連絡ください。

      また、まだ個別相談枠に空きがございます（残り5枠）。
      ...

  day_7:
    timing: 7日後
    recipients: 個別相談未予約 + メール未開封
    subject: "【最終案内】GA4個別相談 - 今週で締め切ります"
    content: |
      {参加者名} 様

      GA4ウェビナーの個別相談について、
      今週末で募集を締め切らせていただきます。

      現在、残り2枠のみとなっております。
      ...
```

### 6. 効果測定レポート（Analytics Report）

**Output**:
```yaml
webinar_analytics:
  registration:
    total_registrants: 47名
    target: 30名
    achievement_rate: 156%

  attendance:
    total_attendees: 28名
    attendance_rate: 59.6%
    target_rate: 50%
    achievement: ✅ 達成

  engagement:
    average_stay_duration: 52分
    chat_messages: 34件
    questions_submitted: 12件
    poll_participation_rate: 82%

  conversion:
    resource_download: 24名 (85.7%)
    consultation_booking: 5名 (17.9%)
    target_consultations: 3名
    achievement: ✅ 達成

  roi_analysis:
    cost:
      platform_fee: ¥0 (Zoom無料)
      promotion_ad: ¥15,000
      preparation_time: 8時間 (¥40,000相当)
      total: ¥55,000

    value:
      qualified_leads: 5件
      avg_deal_size: ¥300,000
      close_rate_estimate: 20%
      expected_revenue: ¥300,000
      roi: 445%

  improvements:
    - 参加率が目標を上回った（59.6% > 50%）
    - 商談化率は目標達成（5件 > 3件）
    - 次回は質疑応答時間を15分に延長すべき
    - リマインダーメールの効果が高い（開封率78%）
```

---

## 🔗 Dependencies

### Upstream Dependencies (Input元)
- **PersonaAgent**: ターゲットオーディエンス定義
- **ContentCreationAgent**: ブログ記事・告知文作成
- **MarketingAgent**: 集客戦略
- **SalesAgent**: フォローアップ戦略

### Downstream Dependencies (Output先)
- **SlideGenAgent**: スライド生成
- **ImageGenAgent**: バナー・サムネイル生成
- **AnalyticsAgent**: 効果測定・レポート
- **CRMAgent**: リード管理・商談化

---

## 🚀 Execution Workflow

### Phase 1: Planning (Day 1-3)
```bash
1. Input収集
   - ICP定義 (from PersonaAgent)
   - ウェビナーテーマ
   - 目標KPI

2. アジェンダ設計
   - 60分構成案
   - スライドアウトライン
   - デモシナリオ

3. Output
   - ウェビナー企画書
```

### Phase 2: Content Creation (Day 4-7)
```bash
1. 台本生成
   - 全セクション台本
   - トランジション
   - アイスブレイク

2. Q&Aシナリオ作成
   - 想定質問リスト
   - 回答テンプレート

3. Output
   - 完全台本（Markdown）
   - スライド構成案 → SlideGenAgent
```

### Phase 3: Promotion (Day 8-14)
```bash
1. 告知戦略立案
   - 14日前、7日前、3日前、1日前タイムライン
   - チャネル別コンテンツ

2. 告知コンテンツ生成
   - LinkedIn投稿（3本）
   - メールテンプレート（4本）
   - バナー要件定義 → ImageGenAgent

3. Output
   - 告知計画書
   - 投稿テンプレート集
```

### Phase 4: Execution (Day 15)
```bash
1. 最終チェックリスト
   - Zoom設定確認
   - スライド最終版
   - Q&Aシート準備

2. リマインダー送信
   - 1時間前メール
   - 30分前SNS投稿

3. 本番サポート
   - タイムキーパー
   - Q&Aモデレーション
```

### Phase 5: Follow-up (Day 16-23)
```bash
1. 即時フォローアップ
   - 1時間以内: 資料送付メール
   - アンケート送信

2. ナーチャリング
   - Day 3: 質問確認メール
   - Day 7: 最終案内メール

3. 効果測定
   - 参加率分析
   - 商談化率計測
   - ROI算出

4. Output
   - 効果測定レポート → AnalyticsAgent
   - リード情報 → CRMAgent
```

---

## 📊 KPIs

### Input KPIs (成功条件)
- **申込率**: 30名以上
- **参加率**: 50%以上
- **商談化**: 3件以上

### Output KPIs (Agent性能)
- **企画完了時間**: 3日以内
- **台本品質スコア**: 8/10以上（人間レビュー）
- **告知コンテンツ生成**: 10本/1日
- **フォローアップ自動化率**: 100%

### Business Impact KPIs
- **リード獲得単価**: ¥2,000以下
- **商談化率**: 15%以上
- **ROI**: 300%以上

---

## 🛠️ Technical Implementation

### Tools & APIs
```yaml
primary_tools:
  - Zoom API (optional): ウェビナー設定自動化
  - Google Meet API (optional): 代替プラットフォーム
  - Calendly API: 個別相談予約
  - Mailchimp/SendGrid: メール自動送信

llm_tools:
  - Claude Sonnet 4: 台本生成、Q&A作成
  - Prompt Engineering: セクション別専用プロンプト

analytics_tools:
  - Google Analytics: ランディングページ分析
  - Zoom Analytics: 参加データ取得
```

### Prompt Templates

**台本生成プロンプト**:
```markdown
# ウェビナー台本生成

あなたはウェビナー台本作成の専門家です。

## Input情報
- テーマ: {theme}
- ターゲット: {target_audience}
- 時間: 60分
- アジェンダ: {agenda}

## 要件
1. 各セクションごとに詳細な台本を作成
2. アイスブレイクを3箇所以上配置
3. 質問を投げかける形式で参加者を巻き込む
4. 専門用語は必ず簡単な言葉で言い換える
5. データや事例を最低5つ引用

## Output形式
Markdown形式で、タイムスタンプ付き台本

## Example
00:00-05:00 オープニング
「皆さん、本日は...」
[アイスブレイク: チャットで1か2を入力してもらう]
...
```

---

## 📝 Example Execution

### Command
```bash
# WebinarAgent実行（Mayu GTM戦略 Phase 3）
npm run agents:webinar -- \
  --issue 44 \
  --theme "GA4完全攻略" \
  --target "B2B SaaS マーケター" \
  --duration 60 \
  --goal-registrants 30 \
  --goal-attendance-rate 50 \
  --goal-consultations 3
```

### Output Files
```
artifacts/webinar_44/
├── webinar_plan.yaml
├── script_full.md
├── slides_outline.md
├── qa_scenarios.yaml
├── promotion_plan.yaml
├── followup_sequence.yaml
└── analytics_report.yaml
```

---

## 🎯 Use Cases

### Use Case 1: Mayu GTM Strategy
- **Task**: #44 ウェビナー企画、#46 ウェビナー実施
- **Goal**: 申込30名、参加率50%、商談3件
- **Timeline**: 14日間（企画3日 + 告知10日 + 実施1日）

### Use Case 2: Product Launch Webinar
- **Task**: 新製品発表ウェビナー
- **Goal**: 認知度向上、メディア露出
- **Timeline**: 21日間

### Use Case 3: Customer Training
- **Task**: 既存顧客向けトレーニング
- **Goal**: オンボーディング完了率80%
- **Timeline**: 継続的実施（月1回）

---

## 🔄 Continuous Improvement

### Feedback Loop
1. ウェビナー終了後、参加者アンケート分析
2. Q&Aで多かった質問をFAQに追加
3. 次回の台本に改善点を反映
4. A/Bテストで最適な告知文を特定

### Version History
- **v1.0.0** (2025-11-10): 初版リリース
- **v1.1.0** (予定): Zoom API統合
- **v2.0.0** (予定): AIモデレーター機能追加

---

## 📚 Related Documentation

- **Prompt Template**: `../../prompts/business/webinar-agent-prompt.md`
- **Example Outputs**: `../../examples/webinar-examples.md`
- **Integration Guide**: `../../../docs/WEBINAR_INTEGRATION.md`

---

**Status**: ✅ Ready for Production
**Maintainer**: Miyabi Business Agent Team
**Last Updated**: 2025-11-10

🎯 **WebinarAgent - ウェビナーを完全自動化し、商談獲得を最大化する！**
